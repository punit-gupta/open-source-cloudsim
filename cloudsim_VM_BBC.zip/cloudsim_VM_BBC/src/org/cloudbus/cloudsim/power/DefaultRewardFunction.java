package org.cloudbus.cloudsim.power;

public class DefaultRewardFunction extends RewardFunction {

	public DefaultRewardFunction() {
		// TODO Auto-generated constructor stub
	}

	public DefaultRewardFunction(Domain domain) {
		super(domain);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double computeRewardFunctionValue(PowerHost h) {
		
		double rfval = h.getMaxPower()- h.getPower();
		
		return rfval;
	}

}
