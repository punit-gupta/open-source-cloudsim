/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim.power;

/**
 *
 * @author admin
 */
public class proposed_constant {
    
    public static double alpha=40;
    public static double beta=60;
    public static double gama=80;
    
}
