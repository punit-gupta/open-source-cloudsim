/*
* Tour.java
* Stores a candidate tour
*/

package org.cloudbus.cloudsim;

import java.rmi.dgc.VMID;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

import org.cloudbus.cloudsim.lists.VmList;

public class Tour{

    // Holds our tour of cities
    public ArrayList<Vm> tour = new ArrayList<Vm>();
    public ArrayList<Host> host = new ArrayList<Host>();
    // Cache
    private double fitness = 0;
    private int distance = 0;
    public int fault = 0;
    
    // Constructs a blank tour
    public Tour(){
        for (int i = 0; i < TourManager.numberOfCities(); i++) {
            tour.add(null);
        }
        
        host=TourManager.hosts;
    }
    
    public Tour(ArrayList tour){
        this.tour = tour;
    }

    // Creates a random individual
    public void generateIndividual() 
    {   
        Random rand = new Random();
         //TourManager.getCity(0).host1 =TourManager.hosts.get(0);
          
         // setCity(0, TourManager.getCity(0));
       // Loop through all our destination cities and add them to our tour
        for (int cityIndex = 0; cityIndex < TourManager.numberOfCities(); cityIndex++) 
        {
            int randomNum = (int) (Math.random() * TourManager.hosts.size());
          //System.out.print(randomNum);
          while(!host.get(randomNum).isSuitableForVm(TourManager.getCity(cityIndex)))
          {
          randomNum=(int) (Math.random() * host.size());
          
          }
          TourManager.getCity(cityIndex).host1 =host.get(randomNum);
          TourManager.getCity(cityIndex).hostid=randomNum;
          setCity(cityIndex, TourManager.getCity(cityIndex));
          Vm vm= TourManager.getCity(cityIndex);
          Host h=host.get(randomNum);
          
          h.getRamProvisioner().allocateRamForVm(vm, vm.getCurrentRequestedRam());
	  h.getBwProvisioner().allocateBwForVm(vm, vm.getCurrentRequestedBw());
	  h.getVmScheduler().allocatePesForVm(vm, vm.getCurrentRequestedMips());
	  h.setStorage(h.getStorage() - vm.getSize());
          
         //Log.printLine(randomNum+" vmid:"+TourManager.getCity(cityIndex).id);
         
        }
        
        for (int i = 0; i < host.size(); i++) {
            fitness=(host.get(i).getTotalMips()-host.get(i).getAvailableMips())/host.get(i).getTotalMips()+fitness;
            
         }
        fitness=fitness/host.size();
        
         for (int i = 0; i < host.size(); i++) {
            host.get(i).vmDeallocateAll();
            host.get(i).setStorage(host.get(i).max_storage);
            
         }
         Log.printLine("utilization"+fitness);
        
        
        
        //Randomly reorder the tour
        //Collections.shuffle(tour);
       // System.out.println("\n"+getDistance());
    }

    // Gets a city from the tour
    public Vm getCity(int tourPosition) {
        return (Vm)tour.get(tourPosition);
    }

    // Sets a city in a certain position within a tour
    public void setCity(int tourPosition, Vm city) {
        tour.set(tourPosition, city);
        // If the tours been altered we need to reset the fitness and distance
        fitness = 0;
        distance = 0;
    }
    
    // Gets the tours fitness
    public double getFitness() {
            
            for (int cityIndex = 0; cityIndex < TourManager.numberOfCities(); cityIndex++) 
            {
            
          Vm vm= tour.get(cityIndex);
          Host h=vm.host1;
          
          h.getRamProvisioner().allocateRamForVm(vm, vm.getCurrentRequestedRam());
	  h.getBwProvisioner().allocateBwForVm(vm, vm.getCurrentRequestedBw());
	  h.getVmScheduler().allocatePesForVm(vm, vm.getCurrentRequestedMips());
	  h.setStorage(h.getStorage() - vm.getSize());
         
        }
        
        for (int i = 0; i < TourManager.hosts.size(); i++) {
            fitness=(host.get(i).getTotalMips()-host.get(i).getAvailableMips())/host.get(i).getTotalMips()+fitness;
            
         }
        fitness=fitness/host.size();
        
         for (int i = 0; i < TourManager.hosts.size(); i++) {
            host.get(i).vmDeallocateAll();
            host.get(i).setStorage(host.get(i).max_storage);
         }
         
        
        return fitness;
    }

    public int getfault(){
        int fault1=0;
            for (int cityIndex=0; cityIndex < tourSize(); cityIndex++) 
            {
                // Get city we're travelling from
                Vm fromCity = getCity(cityIndex);

               // fault1=(int) VmList.getById(hostlist, fromCity.getVmId()).fault+fault1;
                }
        
        return fault1;
    }
    
    public int getmpis(){
        int fault1=0;
            for (int cityIndex=0; cityIndex < tourSize(); cityIndex++) 
            {
                // Get city we're travelling from
                Vm fromCity = getCity(cityIndex);

               // fault1=(int) VmList.getById(hostlist, fromCity).mips+fault1;
                }
        
        return fault1;
    }

    // Get number of cities on our tour
    public int tourSize() {
        return tour.size();
    }
    
    // Check if the tour contains a city
    public boolean containsCity(Vm city){
        return tour.contains(city);
    }
    
    @Override
    public String toString() {
        String geneString = "|";
        for (int i = 0; i < tourSize(); i++) {
            geneString += getCity(i)+"|";
        }
        return geneString;
    }
    
    
    
   public static void sortcloudlet()
    { 
       Vm c;
        int id=0;
        for (int i=0;i<TourManager.destinationCities.size();i++) 
        {   
            c=(Vm) TourManager.destinationCities.get(i);
            id=i;
            for(int j=i;j<TourManager.destinationCities.size();j++)
            {  Vm c1=(Vm)TourManager.destinationCities.get(j);            
              if(c.mips< c1.mips)
              { 
               id=j;
               
              }
            }

            Collections.swap(TourManager.destinationCities,i,id);
            //Log.printLine(vmList.get(i).priority);

        }
        
        for (int i=0;i<TourManager.destinationCities.size();i++) 
        {   c=(Vm) TourManager.destinationCities.get(i);
          
         // System.out.println("datacenter"+c.mips);
        }
        
    
    
    }

   public static void sort()
    { 
       Host c;
        int id=0;
        for (int i=0;i<TourManager.hosts.size();i++) 
        {   
            c=(Host) TourManager.hosts.get(i);
            id=i;
            for(int j=i;j<TourManager.hosts.size();j++)
            {  Host c1=(Host)TourManager.hosts.get(j);            
              if(c.getTotalMips()< c1.getTotalMips()  )
              { 
               id=j;
               
              }
            }

            Collections.swap(TourManager.hosts,i,id);
            //Log.printLine(vmList.get(i).priority);

        }
        
        for (int i=0;i<TourManager.hosts.size();i++) 
        {   c= TourManager.hosts.get(i);
          
          //System.out.println("datacenter"+c.getTotalMips());
        }
        
    
    
    }

   
   
}
