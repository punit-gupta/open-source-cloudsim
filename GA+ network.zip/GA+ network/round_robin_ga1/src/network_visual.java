
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.NetworkTopology;
import org.cloudbus.cloudsim.core.CloudSim;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author punitgupta
 */
public class network_visual 
{
    public void visual(List<Datacenter> d,DatacenterBroker broker) throws IOException
    { 
      String path="1.html";
      FileWriter fw = new FileWriter(path);
      PrintWriter pw = new PrintWriter(fw);

    
pw.println("<!DOCTYPE html>\n" +
"<html>\n" +
"<head>\n" +
"    <style>\n" +
"  html,\n" +
"body {\n" +
"  width: 100%;\n" +
"  height: 100%;\n" +
"  padding: 0;\n" +
"  margin: 0;\n" +
"}\n" +
"#a {\n" +
"  color: white;\n" +
"  text-align: center;\n" +
"  padding: 10px;\n" +
"  position: fixed;\n" +
"  width: 100px;\n" +
"  height: 20px;\n" +
"  left: 0px;\n" +
"}\n" +
"#b {\n" +
"  color: white;\n" +
"  text-align: center;\n" +
"  padding: 10px;\n" +
"  position: fixed;\n" +
"  width: 100px;\n" +
"  height: 20px;\n" +
" \n" +
"}\n" +
"    \n" );

for(int i=0;i<d.size();i++)
     {
     pw.println( "    #c"+i+"{\n" +
                     "  color: white;\n" +
                     "  text-align: center;\n" +
                     "  width: 70px;\n" +
                     "  height: 80px;\n" +
                     "  background-color: green;\n" +
                     "  bottom: 300px;\n" +
                     "  \n" +
                     "}\n");
     
     }

pw.println(
     

"       \n" +
"#a {\n" +
"  background-color: blue;\n" +
"  top: 20px;\n" +
"}\n" +
"#b {\n" +
"  background-color: red;\n" +
"  bottom: 20px;\n" +
"}\n" );


pw.println(
"    </style>\n" +
"    \n" +
"    \n" +
"    \n" +
"    \n" +
"    </head>\n" +
"<body>\n" +
"    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js\"></script>\n" +
"<script src=\"https://ajax.googleapis.com/ajax/libs/jqueryui/1.12.0/jquery-ui.min.js\"></script>\n" +
"    \n" +
"<svg xmlns=\"http://www.w3.org/2000/svg\" width=\"100%\" height=\"100%\">\n" +
"  <defs>\n" +
"    <marker id=\"arrowhead\" viewBox=\"0 0 10 10\" refX=\"3\" refY=\"5\"\n" +
"        markerWidth=\"6\" markerHeight=\"6\" orient=\"auto\">\n" +
"      <path d=\"M 0 0 L 10 5 L 0 10 z\" />\n" +
"    </marker>\n" +
"  </defs>\n" +
"  <g fill=\"none\" stroke=\"black\" stroke-width=\"2\" marker-end=\"url(#arrowhead)\">\n" +
"    \n" );

for(int i=0;i<d.size();i++)
     {

pw.println(
"    <path id=\"arrowRight"+i+"\" />\n" +
"      <text font-family=\"Verdana\" font-size=\"15\" fill=\"blue\">\n" +
"      <textPath href=\"#arrowRight"+i+"\" startOffset=\"50%\">"+"Delay"+"-"+NetworkTopology.getDelay( d.get(i).getId(),broker.getId())+"</textPath>\n" +
"    </text>\n" +
"    <path id=\"arrowRight"+i+"\"/>\n" );
//System.out.println();


     }


pw.println("  </g>\n" +
"</svg>\n" +
"     <div id=\"a\">Cloud Broker 0</div>\n" +
"\n" +
"<table cellspacing=\"50\">\n" +
"    <tr>\n" +
"       \n" );

for(int i=0;i<d.size();i++)
     {
pw.println(
"        <td><div style=\"word-wrap: break-word\" id=\"c"+i+"\">"+d.get(i).getName()+"<br>");

        for(int j=0;j<d.get(i).getHostList().size();j++)
        {
        pw.println("Host "+d.get(i).getHostList().get(j).getId());
        
        }

 pw.println("</div></td>\n" +
        "        \n");

     }

 
pw.println(
"    </tr>\n" +
"    </table>    \n" +
"    \n" +
"    \n" +
"    \n" +
"    <script type=\"text/javascript\">\n" +
"        var divA       = document.querySelector(\"#a\");\n" );


for(int i=0;i<d.size();i++)
     {
       
pw.println("        var divC"+i+"       = document.querySelector(\"#c"+i+"\");    \n" +
"var arrowRight"+i+"  = document.querySelector(\"#arrowRight"+i+"\");\n" );
        }
   
        
 pw.println(       
        "\n" +
"\n" +
"var drawConnector = function() {\n" +
"  var posnALeft = {\n" +
"    x: divA.offsetLeft - 8,\n" +
"    y: divA.offsetTop  + divA.offsetHeight / 2\n" +
"  };\n" +
"  var posnARight = {\n" +
"     x: divA.offsetLeft + divA.offsetWidth + 8,\n" +
"    y: divA.offsetTop  + divA.offsetHeight / 2   \n" +
"  };\n" +
"    \n" +
"    \n" );
 
 for(int i=0;i<d.size();i++)
     {
 
 pw.println(
"  var posnC"+i+"Left = {\n" +
"    x: divC"+i+".offset - 8,\n" +
"    y: divC"+i+".offsetTop  + divA.offsetHeight / 2\n" +
"  };\n" +
"  var posnC"+i+"Right = {\n" +
"    x: divC"+i+".offsetLeft + divC"+i+".offsetWidth -20,\n" +
"    y: divC"+i+".offsetTop  + divA.offsetHeight / 2 -20\n" + 
"  };\n" +

"  var dStrRight"+i+" =\n" +
"      \"M\" +\n" +
"      (posnC"+i+"Right.x      ) + \",\" + (posnC"+i+"Right.y) + \" \" +\n" +
"      \"C\" +\n" +
"      (posnC"+i+"Right.x + 10) + \",\" + (posnC"+i+"Right.y) + \" \" +\n" +
"      (posnARight.x + 50) + \",\" + (posnARight.y) + \" \" +\n" +
"      (posnARight.x      ) + \",\" + (posnARight.y);\n" +
"  arrowRight"+i+".setAttribute(\"d\", dStrRight"+i+");\n" );
     }
 
 pw.println("};\n" );
 pw.print("$(\"#a, #b");
 for(int i=0;i<d.size();i++)
     {
pw.append(", #c"+i);
     }

pw.print(
"\").draggable({\n" +
"  drag: function(event, ui) {\n" +
"    drawConnector();\n" +
"  }\n" +
"});\n" +
"\n" +
"drawConnector();\n" +
"    </script>\n" +
"</body>\n" +
"</html>");
   
    pw.flush();

        //Close the Print Writer
        pw.close();

        //Close the File Writer
        fw.close();
    
    
    }
    
}
