package org.cloudbus.cloudsim.power;

public abstract class RewardFunction {
	protected Domain domain;

	public RewardFunction() {
		// TODO Auto-generated constructor stub
	}
	
	public RewardFunction(Domain domain){
		this.domain = domain;
	}
	
	public abstract double computeRewardFunctionValue(PowerHost h);
	

}
