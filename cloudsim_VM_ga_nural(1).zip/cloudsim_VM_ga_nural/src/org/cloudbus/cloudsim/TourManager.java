/*
* TourManager.java
* Holds the cities of a tour
*/

package org.cloudbus.cloudsim;

import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.lists.VmList;

public class TourManager {

    // Holds our cities
    public static ArrayList<Vm> destinationCities = new ArrayList<Vm>();
    public static ArrayList<Host> hosts = new ArrayList<Host>();
    //public static List< Host> hostlist=new ArrayList<Host>();
    // Adds a destination city
    public static void addCity(Vm city) {
        destinationCities.add(city);
    }
    
    // Get a city
    public static Vm getCity(int index){
        return (Vm)destinationCities.get(index);
    }
    
    // Get the number of destination cities
    public static int numberOfCities(){
        return destinationCities.size();
    }
    
    
    public static double distanceTo(Vm city)
    {  
    
        Host v  = city.host1;
      
        double distance=v.getAvailableMips();
        //System.out.println(distance);
        return distance;
    }
}
