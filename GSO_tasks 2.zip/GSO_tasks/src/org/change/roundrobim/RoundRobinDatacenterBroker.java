package org.change.roundrobim;

import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;

import org.cloudbus.cloudsim.DatacenterBroker;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.DefaultConfiguration;
import org.cloudbus.cloudsim.GSOConfiguration;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.RewardFunction;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.core.CloudSimTags;
import org.cloudbus.cloudsim.core.SimEvent;
import org.cloudbus.cloudsim.lists.VmList;
import static org.cloudbus.cloudsim.examples.CloudSim_Roundrobin.*;

public class RoundRobinDatacenterBroker extends DatacenterBroker {
     RewardFunction rf;

 
    public RoundRobinDatacenterBroker(String name) throws Exception {
        super(name);
         
    }

    @Override
    public void processResourceCharacteristics(SimEvent ev) {
        DatacenterCharacteristics characteristics = (DatacenterCharacteristics) ev.getData();
        getDatacenterCharacteristicsList().put(characteristics.getId(), characteristics);

        if (getDatacenterCharacteristicsList().size() == getDatacenterIdsList().size()) {
            createVmsInDatacenter(getDatacenterIdsList());
        }
    }

    public void createVmsInDatacenter(List<Integer> datacenterIds) {

        int requestedVms = 0;
        int i = 0;
        for (Vm vm : getVmList()) {
         //   System.out.println("vm cost:"+vm.mips+":"+vm.ram+":"+vm.size+":vmId-"+vm.uid +"\n");
            int datacenterId = datacenterIds.get(i++ % datacenterIds.size());
            DatacenterCharacteristics d=datacenterCharacteristicsList.get(datacenterId);
            System.out.println(d.getCostPerBw()+"--"+d.getCostPerMem());
            String datacenterName = CloudSim.getEntityName(datacenterId);
            if (!getVmsToDatacentersMap().containsKey(vm.getId())) {
                Log.printLine(CloudSim.clock() + ": " + getName() + ": Trying to Create VM #" + vm.getId() + " in " + datacenterName);
                sendNow(datacenterId, CloudSimTags.VM_CREATE_ACK, vm);
                requestedVms++;
            }
        }

        setVmsRequested(requestedVms);
        setVmsAcks(0);
    }
    
  protected void submitCloudlets()
        {
		int vmIndex = 0;
            for (Cloudlet cloudlet : getCloudletList()) 
                {
			Vm vm;
			// if user didn't bind this cloudlet and it has not been executed yet
			if (cloudlet.getVmId() == -1) 
                        {       vm = GSO(cloudlet);
                                vm.start_time=vm.start_time+(cloudlet.getCloudletLength()/vm.mips);
                               
                                
				
			} else { // submit to the specific vm
				vm = VmList.getById(getVmsCreatedList(), cloudlet.getVmId());
				if (vm == null) { // vm was not created
					Log.printLine(CloudSim.clock() + ": " + getName() + ": Postponing execution of cloudlet "
							+ cloudlet.getCloudletId() + ": bount VM not available");
					continue;
				}
			}
                        if(vm!=null)
                        {
			Log.printLine(CloudSim.clock() + ": " + getName() + ": Sending cloudlet "
					+ cloudlet.getCloudletId() + " to VM #" + vm.getId()+"-"+vm.getState());
			cloudlet.setVmId(vm.getId());
			sendNow(getVmsToDatacentersMap().get(vm.getId()), CloudSimTags.CLOUDLET_SUBMIT, cloudlet);
			cloudletsSubmitted++;
			vmIndex = (vmIndex + 1) % getVmsCreatedList().size();
			getCloudletSubmittedList().add(cloudlet);
                        }
                }
		// remove submitted cloudlets from waiting list
		for (Cloudlet cloudlet : getCloudletSubmittedList()) 
                {
                  
                        getCloudletList().remove(cloudlet);
                        
               }
	}
        
        
   protected void processCloudletReturn(SimEvent ev) {
		Cloudlet cloudlet = (Cloudlet) ev.getData();
		getCloudletReceivedList().add(cloudlet);
		Log.printLine(CloudSim.clock() + ": " + getName() + ": Cloudlet " + cloudlet.getCloudletId()
				+ " received");
		cloudletsSubmitted--;
           
                
		if (getCloudletList().size() == 0 && cloudletsSubmitted == 0) { // all cloudlets executed
			Log.printLine(CloudSim.clock() + ": " + getName() + ": All Cloudlets executed. Finishing...");
			clearDatacenters();
			finishExecution();
		} else { // some cloudlets haven't finished yet
			if (getCloudletList().size() > 0 && cloudletsSubmitted == 0) {
				// all the cloudlets sent finished. It means that some bount
				// cloudlet is waiting its VM be created
				clearDatacenters();
				createVmsInDatacenter(0);
			}

		}
	}     
        
        
   public Vm GSO(Cloudlet c)
   {   updateLuciferin(c);    
       Vm allocatedHost = null;
                               Vm p=getVmsCreatedList().get(0);
                   
                                   int myIndex=0 ;
                                   for(int i=0;i<getVmsCreatedList().size();i++)
                                       { if(getVmsCreatedList().get(i)==p)
                                            {myIndex=i;
                                            //System.out.println("found"+i);
                                            }

                                       }

                                    
                                    double power_after=0,power_after1=0,allocatedhost_power=0,diff=0;
                                    int allocatedhost_id=0;
                                     List<Vm> selected=new ArrayList<>();
                                     int selected1=0,selected2=0;
                                     int i=0;
                                   do
                                   {
                                  
                                    if(i==0)
                                    {   p.a.planMove(getVmsCreatedList(), myIndex, config.stepSize,c,selected);
                                        selected.add(p.a.approachable);
                                        selected1=p.a.approachable.getId();

                                        if(p.a.approachable!=null)
                                        {
                                        power_after=(c.getCloudletLength()/p.a.approachable.mips)+p.a.approachable.start_time;

                                        Log.printLine("selected:1 "+p.a.approachable.getId()+"- "+power_after);
                                        }
                                   }
                                   
                                   p.a.planMove(getVmsCreatedList(), myIndex, config.stepSize,c,selected);

                                   selected.add(p.a.approachable);
                                   selected2=p.a.approachable.getId();
                                        if(p.a.approachable!=null)
                                        {power_after1=(c.getCloudletLength()/p.a.approachable.mips)+p.a.approachable.start_time;

                                        Log.printLine("selected:2 "+p.a.approachable.getId()+"- "+power_after1);
                                        }
                                   
                                   if(i==0)
                                   {  if(power_after>power_after1)
                                        {allocatedhost_id=selected2;
                                         allocatedhost_power=power_after1;
                                         diff=power_after-power_after1;
                                        }
                                       else
                                        {allocatedhost_id=selected1;
                                         allocatedhost_power=power_after;
                                         diff=power_after-power_after1;
                                        }
                                    i++;   
                                   }
                                   else
                                   {  if(allocatedhost_power>power_after1)
                                        {allocatedhost_id=selected2;
                                         
                                         diff=allocatedhost_power-power_after1;
                                         allocatedhost_power=power_after1;
                                        }
                                      else
                                        {
                                         diff=allocatedhost_power-power_after1;
                                         
                                        }
                                   }
                                        
                                     
                                       System.out.println(i+"- "+diff);
                                   
                                   }while(diff>0);

                                   // System.out.println(allocatedhost_id);

                                   if(p.a.approachable!=null)
                                   {
                                    for(int j=0;j< getVmsCreatedList().size();j++)   
                                    { if(getVmsCreatedList().get(j).getId()==allocatedhost_id)
                                        {allocatedHost= getVmsCreatedList().get(j);
                                        }
                                    }
                                   Log.printLine("final selected"+allocatedHost.getId());
                                   }
                                   
                                   
                                   if(allocatedHost==null)
                                   {
                                   Log.printLine("no host for null");
                                   }
                                  else
                                   {Log.printLine("allocation");
                                       //Log.printLine("host:id "+ allocatedHost.getId()+ " is selected for vm "+vm.getId());

                                   }
         updateSensorRanges();
          allocatedHost.start_time=(c.getCloudletLength()/allocatedHost.mips)+allocatedHost.start_time;
         return allocatedHost;
   }
   
   
   public void updateSensorRanges(){
		 for(Vm h: getVmsCreatedList()){
			h.a.updateSensorRange(config.getMaxSensorRange(),
					config.getDesiredNumberOfNeighbors(),
					config.getBeta());
		}
	}
        
        public void updateLuciferin(Cloudlet c){
		 rf = config.getRf();
                 
                       for(Vm h :getVmsCreatedList())
                       { // For every Agent 'a' in agents
                         
                           h.a.luciferin=(c.getCloudletLength()/h.mips)+h.start_time;
                           System.out.println(h.start_time);
                           h.a.updateLuciferin(rf.computeRewardFunctionValue(h,c));
		      }
	}
   
}