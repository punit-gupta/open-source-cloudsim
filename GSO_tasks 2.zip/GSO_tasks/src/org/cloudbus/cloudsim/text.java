/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class text 
{
    String textdata;

    String getTextData(){
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the text");
    textdata=scan.nextLine();
    return textdata;
     
}
}
