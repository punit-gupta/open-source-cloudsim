/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class login 
{
    String logindetail;
 
  String getLoginDetails(){
    Scanner scan=new Scanner(System.in);
    System.out.println("Enter the Logindetails");
    logindetail=scan.nextLine();
    return logindetail;
    
    }
}
