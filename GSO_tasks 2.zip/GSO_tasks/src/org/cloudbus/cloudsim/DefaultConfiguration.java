package org.cloudbus.cloudsim;

public class DefaultConfiguration extends GSOConfiguration {
	

	public DefaultConfiguration() {
		double[] lowerBounds = {0,0};
		double[] upperBounds = {1,1};
		this.domain = new EuclideanDomain(2, lowerBounds, upperBounds);
		
		this.population = 100;
		this.maxIterations = 1000000;
		
		this.decayConstant = 1;
		this.enhancementConstant = 1;
		this.stepSize = 0.005;
		this.initialSensorRange = 0.2;
		this.maxSensorRange = 1.0;
		
		this.initialLuciferin = 0.5;
		this.desiredNumberOfNeighbors = 10;
		this.beta = 0.01;
		this.rf = new DefaultRewardFunction();
		this.maxIterations=5;
		
	}

}
