package org.cloudbus.cloudsim;

public class EuclideanDomain extends Domain {
	private int dimensions;
	private double[] lowerBounds;
	private double[] upperBounds;
	

	public EuclideanDomain() {
		
	}
	public EuclideanDomain(int dimensions, double[] lb, double[] ub){
		this.dimensions = dimensions;
		this.lowerBounds = lb;
		this.upperBounds = ub;
	}
	public int getDimensions() {
		return dimensions;
	}
	public double[] getLowerBounds() {
		return lowerBounds;
	}
	public double[] getUpperBounds() {
		return upperBounds;
	}
	
	

}
