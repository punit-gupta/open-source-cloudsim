package org.cloudbus.cloudsim;

import org.cloudbus.cloudsim.core.CloudSim;

public class DefaultRewardFunction extends RewardFunction {

	public DefaultRewardFunction() {
		// TODO Auto-generated constructor stub
	}

	public DefaultRewardFunction(Domain domain) {
		super(domain);
		// TODO Auto-generated constructor stub
	}

	@Override
	public double computeRewardFunctionValue(Vm h,Cloudlet c) {
		
		double rfval =c.getCloudletLength()/h.getMips();
		
		return rfval;
	}

}
