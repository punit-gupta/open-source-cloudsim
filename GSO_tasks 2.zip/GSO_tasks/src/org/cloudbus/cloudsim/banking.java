/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.cloudbus.cloudsim;

import java.util.Scanner;

/**
 *
 * @author Admin
 */
public class banking 
{
     String cardNo;
   

   String getcardNo(){
       Scanner scan=new Scanner(System.in);
   System.out.println("Enter the card no");
   cardNo=scan.nextLine();
   return cardNo;
   
   }

    

   
   }
