package org.cloudbus.cloudsim;

public abstract class GSOConfiguration {
	protected Domain domain; // domain of the space
	protected int population; // number of agents
	protected int maxIterations; // maximum number of iterations before the algorithm terminates
	protected double decayConstant; // decay constant for the the luciferin level
	protected double enhancementConstant; // luciferin enhancement constant
	public double stepSize; 
	protected double initialSensorRange;
	protected double maxSensorRange;
	protected double initialLuciferin;
	protected int desiredNumberOfNeighbors;
	protected double beta;
	protected RewardFunction rf;
        protected double max_iteration=5;
	

	public double getInitialLuciferin() {
		return initialLuciferin;
	}

	public Domain getDomain() {
		return domain;
	}

	public double getSensorRange() {
		return initialSensorRange;
	}

	public int getPopulation() {
		return population;
	}

	public void setPopulation(int population) {
		this.population = population;
	}

	public double getDecayConstant() {
		return decayConstant;
	}

	public void setDecayConstant(double decayConstant) {
		this.decayConstant = decayConstant;
	}

	public double getEnhancementConstant() {
		return enhancementConstant;
	}

	public void setEnhancementConstant(double enhancementConstant) {
		this.enhancementConstant = enhancementConstant;
	}

	public double getStepSize() {
		return stepSize;
	}

	public void setStepSize(double stepSize) {
		this.stepSize = stepSize;
	}

	public int getMaxIterations() {
		return maxIterations;
	}

	public void setMaxIterations(int maxIterations) {
		this.maxIterations = maxIterations;
	}

	public double getMaxSensorRange() {
		return maxSensorRange;
	}

	public int getDesiredNumberOfNeighbors() {
		return desiredNumberOfNeighbors;
	}

	public double getBeta() {
		return beta;
	}

	public RewardFunction getRf() {
		return rf;
	}
	
        public double getmax_iteration() {
		return maxIterations;
	}
	
	
	
	
}
