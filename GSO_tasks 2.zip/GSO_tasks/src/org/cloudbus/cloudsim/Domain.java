package org.cloudbus.cloudsim;

public abstract class Domain {

	public Domain() {
		// TODO Auto-generated constructor stub
	}

}
