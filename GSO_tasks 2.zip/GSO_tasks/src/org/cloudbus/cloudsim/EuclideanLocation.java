package org.cloudbus.cloudsim;

import org.cloudbus.cloudsim.Log;

public class EuclideanLocation extends Location {
	private double[] location;
        static int g=0;
	
	public EuclideanLocation() {}
	
	public EuclideanLocation(Domain domain){
		this.domain = (EuclideanDomain)domain;
		location = new double[((EuclideanDomain)domain).getDimensions()];
	}	

	public double[] getLocation() {
		return location;
	}

	public void setLocation(double[] location) {
		this.location = location;
	}

	@Override
	public void generateRandomLocation(int id) {
            //Log.printLine("Host id"+id+"-"+g);
            
            if(g==0)
            {location[0]=0.5;
             location[1]=0.5;
            }
            if(g==1)
            {location[0]=0.0;
             location[1]=0.0;
            }
            if(g==2)
            {location[0]=1;
             location[1]=1;  
            }
            g++;
            if(g==3)
            {g=0;
            }
            
//            for(int c = 0; c < location.length; c++){
//			location[c] = Math.random() * (((EuclideanDomain)domain).getUpperBounds()[c]-((EuclideanDomain)domain).getLowerBounds()[c])
//					+ ((EuclideanDomain)domain).getLowerBounds()[c];
//		}
	}

	@Override
	public double computeDistanceTo(Location other) {
		double[] otherLocation = ((EuclideanLocation)other).getLocation();
		double tempSum = 0;
		for(int c = 0; c < location.length; c++){
			tempSum += Math.pow((location[c] - otherLocation[c]),2); 
		}
		return Math.sqrt(tempSum);		
	}

	public Location computeNewLocation(Location towardsLocation, double stepSize){
		EuclideanLocation towards = (EuclideanLocation)towardsLocation;
		EuclideanLocation updated = new EuclideanLocation((EuclideanDomain)domain);
		double distance = computeDistanceTo(towards);
		if (distance >= stepSize){
			double[] updatedLocation = new double[updated.getLocation().length];
			for(int c = 0; c < updatedLocation.length; c++){
				updatedLocation[c] = location[c] +  (towards.getLocation()[c] - location[c])*stepSize/distance;
			}
			updated.setLocation(updatedLocation);
			return updated;
		} else {
			return this;
		}
	}
	

	
	public String toString(){
		StringBuilder sb = new StringBuilder();
		sb.append(location[0]);
		for(int c = 1; c < location.length; c++){
			//sb.append("x[").append(c).append("] = ").append(location[c]).append("\n");
			sb.append(',').append(location[c]);
		}
		return sb.toString();
	}
}
