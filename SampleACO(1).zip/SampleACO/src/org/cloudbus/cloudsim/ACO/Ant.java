/*
 * This is a bio inspired algorithms, By: Thanaa Salem.

 */

package org.cloudbus.cloudsim.ACO;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author Thanaa
 */
public class Ant {
    
    FoodSource currFSs ;
    FoodSource bestFSaList;
    double bestpro;
    FoodSource v;
    int id;
    
    
    
    void initalize_ant(Cloudlet c, List<FoodSource> vl)
    {
        Random ran = new Random();
        int id=ran.nextInt(vl.size());
        c.setVmId(vl.get(id).id);
        this.v=vl.get(id);
        v.currLBs=load(v,c);
        v.pro=probability(vl, v);
        
    }
  
    double probability(List<FoodSource> vl,FoodSource v)
    {   double pro=0;
        double tpl= v.currPhs*v.currCps*v.currLBs;
    
        double sumtpl=0;
        
        for(int i=0;i<vl.size();i++)
        { sumtpl=vl.get(i).currPhs*v.currCps*v.currLBs;
            
        }
    
      pro=tpl/sumtpl;
    
    return pro;
    }
    
    double load(FoodSource v,Cloudlet c)
    {   double load=0;
    
        for(int i=0;i<v.ResOfVms.size();i++)
        {
            load=load+(v.ResOfVms.get(i));
        }
        
        if(v.ResOfVms.size()==0)
        {load=0.1;
        
        }
        else
        {
        double resAv =0;
        resAv= load/v.ResOfVms.size();
        
        double exec=(c.getCloudletLength()/v.v.getMips())+v.v.start;
        
             load=1-((exec-resAv)/(exec+resAv));
        }
    return load;
    }
    
    
    
}
