/*
 * This is a bio inspired algorithms, By: Thanaa Salem.

 */

package org.cloudbus.cloudsim.ACO;

import java.util.ArrayList;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author Thanaa
 */
public class Calculations {
    
	static final double OneUnitPheromone = 0.01;
        
	double decayFactor = 0.9;
       
        double beta = 2; //HeuristicImportance:importance of computing capacity
        double alpha = 3; //PheromoneImportance
        double gamma = 8 ;
        
    
    double vmComputingCapacity;
    double vmPheromoneAmount;
    double vmLoadBalancing;
    
    //numerator
    double[] vmComputingCapacityArray;
    double[] vmPheromoneAmountArray;
    double[] vmLoadBalancingArray;
    
    
    //denominator
    double[] totalComputingCapacityArray;
    double[] totalPheromoneAmountArray;
    double tabuLoadBalancingSum;
    private double TabuPpheromoneTrailsum;
    private double TabuVmCpacitysum;
    
    Calculations(double[] capacities, double[] PheromoneAmount, double[] LoadBalancing, double totalCapacities, double totalPheromoneAmount){
        
        
    this.vmComputingCapacityArray = capacities;
    this.vmPheromoneAmountArray = PheromoneAmount;
    this.vmLoadBalancingArray = LoadBalancing;
    
    this.TabuVmCpacitysum = totalCapacities;
    this.TabuPpheromoneTrailsum = totalPheromoneAmount;
        
        
    }
    
    double Probability (double nextTrail , double nextCapacity, double loadbalancingFactor){
    
    
        double Probability = 1;
        double numerator = 1;
        double denominator;

        
        
        
        double trailPowerOfAlpa = 1;
        trailPowerOfAlpa = Math.pow(nextTrail,alpha);
        
        double vmCpacityPowerOfBeta = 1;
        vmCpacityPowerOfBeta = Math.pow(nextCapacity,beta);
        
        double loadbalancingPowerOfGamma = 1;
        loadbalancingPowerOfGamma = Math.pow(loadbalancingFactor,gamma);
        
        double TabuPpheromoneTrailsumPowerOfAlpa = 1;
        TabuPpheromoneTrailsumPowerOfAlpa = Math.pow(TabuPpheromoneTrailsum,alpha);
        
        double TabuVmCpacitysumPowerOfBeta = 1;
        TabuVmCpacitysumPowerOfBeta = Math.pow(TabuVmCpacitysum,beta);
        
        double TabuloadbalancingPowerOfGamma = 1;
        TabuloadbalancingPowerOfGamma = Math.pow(loadbalancingFactor,gamma);
        
        numerator = (trailPowerOfAlpa*vmCpacityPowerOfBeta*loadbalancingPowerOfGamma);
        denominator = (TabuPpheromoneTrailsumPowerOfAlpa * TabuVmCpacitysumPowerOfBeta * TabuloadbalancingPowerOfGamma);
        
        if(denominator!=0){
        
                    Probability = (numerator/denominator);

            
        }
        
        
        return Probability;

    }
    
    double[] LoadBalancingFactor(ArrayList<double[]> vmRunTimes, ArrayList<int[]> OptimalFoodSourcesArrList){
                int m =vmRunTimes.size();

                        double[] LoadbalancingFactor = new double[m];

      
        double timeAvg = 1 ;


		boolean done = false;
		int counter = 0;
		
		while(!done){
			
			double[] timeSum = new double[m];


			for (int i = 0; i < m; i++) {

				double[] time = vmRunTimes.get(i);
				int[] fss = OptimalFoodSourcesArrList.get(i);

				int n = fss.length;

				for (int j = 0; j < n; j++) {
					if (fss[j] == 1) {
						timeSum[i] = timeSum[i] + time[j];//sum of time
					}
				}
                                
                                timeAvg = timeSum[i]/m;
                                LoadbalancingFactor [i] = 1 - ((timeSum[i] - timeAvg)/(timeSum[i] + timeAvg));
			}
    }
                
                
                return LoadbalancingFactor;
    
   
    
}
}
