/*
 * This is a bio inspired algorithms, By: Thanaa Salem.

 */

package org.cloudbus.cloudsim.ACO;

import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author Thanaa
 */
public class FoodSource {
    
    double currPhs;
    double currCps;
    double currLBs;
    
    double pro;
    int id;
    Vm v;
    List<Double> ResOfVms=new ArrayList<Double>();
    
        
        FoodSource(double Ph,double cp,double lb,double probability)
        {
        
        this.currPhs =Ph;
        currPhs = Ph;
        this.currCps = cp;
        currCps = cp;
        this.currLBs = lb;
        currLBs = lb;
        
        pro = probability;
        }
    
}
