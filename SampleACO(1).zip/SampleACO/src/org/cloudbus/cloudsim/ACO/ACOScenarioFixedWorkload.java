/*
 * This is a bio inspired algorithms, By: Thanaa Salem.

 */

package org.cloudbus.cloudsim.ACO;

import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.LinkedList;
import java.util.List;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.CloudletSchedulerSpaceShared;
import org.cloudbus.cloudsim.CloudletSchedulerTimeShared;
import org.cloudbus.cloudsim.Datacenter;
import org.cloudbus.cloudsim.DatacenterCharacteristics;
import org.cloudbus.cloudsim.Host;
import org.cloudbus.cloudsim.Log;
import org.cloudbus.cloudsim.Pe;
import org.cloudbus.cloudsim.Storage;
import org.cloudbus.cloudsim.UtilizationModel;
import org.cloudbus.cloudsim.UtilizationModelFull;
import org.cloudbus.cloudsim.Vm;
import org.cloudbus.cloudsim.VmAllocationPolicySimple;
import org.cloudbus.cloudsim.VmSchedulerTimeShared;
import org.cloudbus.cloudsim.core.CloudSim;
import org.cloudbus.cloudsim.provisioners.BwProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.PeProvisionerSimple;
import org.cloudbus.cloudsim.provisioners.RamProvisionerSimple;

/**
 *
 * @author Thanaa
 */
public class ACOScenarioFixedWorkload {
    
    	/**
	 * Creates main() to run this example.
	 * 
	 * @param args
	 *            the args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		
		try {
			// <<< [1]: Initialize the CloudSim package. It should be called before creating any entities. >>>
			
			int num_user = 1; // number of cloud users
			Calendar calendar = Calendar.getInstance(); // get calendar using current time zone
			boolean trace_flag = false; // mean trace events
			CloudSim.init(num_user, calendar, trace_flag); // Initialize the CloudSim library

			// <<< [2]: Create Datacenters >>>

			Datacenter datacenter0 = createDatacenter("Datacenter_0");
			Datacenter datacenter1 = createDatacenter("Datacenter_1");
                        Datacenter datacenter2 = createDatacenter("Datacenter_2");
                        Datacenter datacenter3 = createDatacenter("Datacenter_3");
                        Datacenter datacenter4 = createDatacenter("Datacenter_4");
                        Datacenter datacenter5 = createDatacenter("Datacenter_5");
                        Datacenter datacenter6 = createDatacenter("Datacenter_6");
                        Datacenter datacenter7 = createDatacenter("Datacenter_7");
                        Datacenter datacenter8 = createDatacenter("Datacenter_8");
                        Datacenter datacenter9 = createDatacenter("Datacenter_9");
                        List<Datacenter> d = new ArrayList<Datacenter>();
                        d.add(datacenter0);
                        d.add(datacenter1);
                        d.add(datacenter2);
                        d.add(datacenter3);
                        d.add(datacenter4);
                        d.add(datacenter5);
                        d.add(datacenter6);
                        d.add(datacenter7);
                        d.add(datacenter8);
                        d.add(datacenter9);

			// <<< [3]: Create Cloud Broker and name it Broker1 >>>
			DatacenterBroker broker = createBroker(1);
			int brokerId = broker.getId(); // gets the id of the created broker

			// <<< [4]: Create 5 virtual machines that uses time shared scheduling >>>
			List<Vm> vmlist =  createVM(brokerId, 40, 0); //creating 30 vms
			

			
			
			// <<< [5]: submit vm list to the broker >>>
			broker.submitVmList(vmlist);
			
			// <<< [6]: Read the workload file and create Cloudlets from it
			List<Cloudlet> cloudletList = createCloudlet(brokerId, 200, 0); // creating 30 cloudlets
			
			// <<< [7]: assign specific VMs to run specific cloudlets --------------------------------------------
			
			broker.UseACO();
			
			for (Cloudlet cloudlet : cloudletList) {
				//set all cloudlets to be managed by one broker.
				cloudlet.setUserId(brokerId);
			}
			
			//---------------------------------------------------------------------------------------------------
			
			// <<< [8]: submit cloudlet list to the broker >>>
			broker.submitCloudletList(cloudletList);

			// <<< [9]: Starts the simulation >>>
			
			//start the simulation
			CloudSim.startSimulation();
			
			//stop the simulation
			CloudSim.stopSimulation();

			// <<< [10]: Print results when simulation is over
			
			//retrieve all recieved cloudlet list
			List<Cloudlet> newList = broker.getCloudletReceivedList();
			
			//print the list
			printCloudletList(newList);
			
		} catch (Exception e) {
			e.printStackTrace();
			Log.printLine("Unwanted errors happen");
		}
	}
	
	/**
	 * Creates the datacenter.
	 * 
	 * desc: Datacenters are the resource providers in CloudSim. We need at
	 *		 least one of them to run a CloudSim simulation
	 * 
	 * @param name
	 *            the name of the data center
	 * 
	 * @return the datacenter
	 */
	private static Datacenter createDatacenter(String name) {

		// Here are the steps needed to create a PowerDatacenter:
		
		// 1. We need to create a list to store our machine
		List<Host> hostList = new ArrayList<Host>();

		// 2. create hosts, where Every Machine contains one or more PEs or CPUs/Cores
		
		//((( Host 1 )))--------------------------------------------------------------------------------------------------------
		List<Pe> Host_1_peList = new ArrayList<Pe>();
		
		//get the mips value of the selected processor
		int Host_1_mips = Processors.Intel.Core_2_Extreme_X6800.mips;
		//get processor's number of cores
		int Host_1_cores = Processors.Intel.Core_2_Extreme_X6800.cores;
		
		// 3. Create PEs and add these into a list.
		for(int i = 0 ; i < Host_1_cores ; i++){
			//mips/cores => MIPS value is cumulative for all cores so we divide the MIPS value among all of the cores
			Host_1_peList.add(new Pe(i, new PeProvisionerSimple(Host_1_mips/Host_1_cores))); // need to store Pe id and MIPS Rating
		}
		
		// 4. Create Host with its id and list of PEs and add them to the list of machines
		int host_1_ID = 1;
		int host_1_ram = 2048; // host memory (MB)
		long host_1_storage = 1048576; // host storage in MBs
		int host_1_bw = 10240; // bandwidth in MB/s
		
		hostList.add(new Host(host_1_ID, new RamProvisionerSimple(host_1_ram),
				new BwProvisionerSimple(host_1_bw), host_1_storage, Host_1_peList,						
				new VmSchedulerTimeShared(Host_1_peList)));
		
		//((( \Host 1 )))--------------------------------------------------------------------------------------------------------
		
		//((( Host 2 )))--------------------------------------------------------------------------------------------------------
		
		List<Pe> Host_2_peList = new ArrayList<Pe>();
		
		//get the mips value of the selected processor
		int Host_2_mips = Processors.Intel.Core_i7_Extreme_Edition_3960X.mips;
		//get processor's number of cores
		int Host_2_cores = Processors.Intel.Core_i7_Extreme_Edition_3960X.cores;
		
		// 3. Create PEs and add these into a list.
		for(int i = 0 ; i < Host_2_cores ; i++){
			//mips/cores => MIPS value is cumulative for all cores so we divide the MIPS value among all of the cores
			Host_2_peList.add(new Pe(i, new PeProvisionerSimple(Host_2_mips/Host_2_cores))); // need to store Pe id and MIPS Rating
		}
		
		// 4. Create Host with its id and list of PEs and add them to the list of machines
		int host_2_id = 2;
		int host_2_ram = 2048; // host memory (MB)
		long host_2_storage = 1048576; // host storage in MBs
		int host_2_bw = 10240; // bandwidth in MB/s
		
		hostList.add(new Host(host_2_id, new RamProvisionerSimple(host_2_ram),
				new BwProvisionerSimple(host_2_bw), host_2_storage, Host_2_peList,						
				new VmSchedulerTimeShared(Host_2_peList)));
		
		//((( \Host 2 )))--------------------------------------------------------------------------------------------------------
		
		// 5. Create a DatacenterCharacteristics object that stores the
		// properties of a data center: architecture, OS, list of
		// Machines, allocation policy: time- or space-shared, time zone
		// and its price (G$/Pe time unit).
		String arch = "x86"; // system architecture
		String os = "Linux"; // operating system
		String vmm = "Xen";
		double time_zone = 10.0; // time zone this resource located
		double cost = 3.0; // the cost of using processing in this resource
		double costPerMem = 0.05; // the cost of using memory in this resource
		double costPerStorage = 0.001; // the cost of using storage in this resource
		double costPerBw = 0.0; // the cost of using bw in this resource
		LinkedList<Storage> storageList = new LinkedList<Storage>(); // we are not adding SAN devices by now

		DatacenterCharacteristics characteristics = new DatacenterCharacteristics(
				arch, os, vmm, hostList, time_zone, cost, costPerMem,
				costPerStorage, costPerBw);

		// 6. Finally, we need to create a PowerDatacenter object.
		Datacenter datacenter = null;
		try {
			datacenter = new Datacenter(name, characteristics,
					new VmAllocationPolicySimple(hostList), storageList, 0);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return datacenter;
	}

	/**
	 * Creates the broker.
	 * 
	 * @param id: the broker id
	 * 
	 * @return the datacenter broker
	 */
	private static DatacenterBroker createBroker(int id) {
		DatacenterBroker broker = null;
		try {
			broker = new DatacenterBroker("Broker"+id);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		return broker;
	}
	
	/**
	 * Creates the virtual machines.
	 * 
	 * @param
	 * 			VMNr: the number of virtual machines to create
	 * 			brokerId: the id of the broker created
	 * 			timeSharedScheduling: to choose between the time shared or space shared shceduling algorithms
	 *
	 * @return list of virtual machines
	 * 
	 */	
	
private static List<Vm> createVM(int userId, int vms, int idShift) {
		//Creates a container to store VMs. This list is passed to the broker later
		LinkedList<Vm> list = new LinkedList<Vm>();

		//VM Parameters
		long size = 10000; //image size (MB)
		int ram = 512; //vm memory (MB)
		int mips = 250;
		long bw = 1000;
		int pesNumber = 1; //number of cpus
		String vmm = "Xen"; //VMM name

		//create VMs
		Vm[] vm = new Vm[vms];

		for(int i=0;i<vms;i++)
                {int p=i%4;
                    if(p==1)
                {
		vm[i] = new Vm(idShift + i, userId, 5*i, pesNumber, ram, bw, size,vmm, new CloudletSchedulerSpaceShared());
		list.add(vm[i]);
                }
                else if(p==2)
                {vm[i] = new Vm(idShift + i, userId, 7*i, pesNumber, ram, bw, size, vmm, new CloudletSchedulerSpaceShared());
			list.add(vm[i]);
                }else if(p==3)
                {vm[i] = new Vm(idShift + i, userId, 8*i, pesNumber, ram, bw, size, vmm, new CloudletSchedulerSpaceShared());
			list.add(vm[i]);
                }
                else 
                {vm[i] = new Vm(idShift + i, userId, 9*i, pesNumber, ram, bw, size ,vmm, new CloudletSchedulerSpaceShared());
			list.add(vm[i]);
                }
                
                }

		return list;
	}


	private static List<Cloudlet> createCloudlet(int userId, int cloudlets, int idShift){
		// Creates a container to store Cloudlets
		LinkedList<Cloudlet> list = new LinkedList<Cloudlet>();

		//cloudlet parameters
		long length = 40000;
		long fileSize = 300;
		long outputSize = 300;
		int pesNumber = 1;
		UtilizationModel utilizationModel = new UtilizationModelFull();

		Cloudlet[] cloudlet = new Cloudlet[cloudlets];

		for(int i=0;i<cloudlets;i++)
                {int p=i%4;
                    
                    if(p==1)
                {
			cloudlet[i] = new Cloudlet(idShift + i, 4000, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			
                        // setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
                }
                else if(p==2)
                {cloudlet[i] = new Cloudlet(idShift + i, 2000, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			
                        // setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
                }else if(p==3)
                {cloudlet[i] = new Cloudlet(idShift + i, 300, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			
                        // setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
                }else
                {
                cloudlet[i] = new Cloudlet(idShift + i, 200, pesNumber, fileSize, outputSize, utilizationModel, utilizationModel, utilizationModel);
			
                        // setting the owner of these Cloudlets
			cloudlet[i].setUserId(userId);
			list.add(cloudlet[i]);
                }
                
                }

		return list;
	}


   
    
    /**
	 * Prints the Cloudlet objects.
	 *
	 * @param list list of Cloudlets
	 */
	private static void printCloudletList(List<Cloudlet> list) {
		int size = list.size();
		Cloudlet cloudlet;

		String indent = "    ";
		Log.printLine();
		Log.printLine("========== OUTPUT ==========");
		Log.printLine("Cloudlet ID" + indent + "STATUS" + indent
				+ "Data center ID" + indent + "VM ID" + indent + "Time" + indent
				+ "Start Time" + indent + "Finish Time");

		DecimalFormat dft = new DecimalFormat("###.##");
		for (int i = 0; i < size; i++) {
			cloudlet = list.get(i);
			Log.print(indent + cloudlet.getCloudletId() + indent + indent);

			if (cloudlet.getCloudletStatus() == Cloudlet.SUCCESS) {
				Log.print("SUCCESS");

				Log.printLine(indent + indent + cloudlet.getResourceId()
						+ indent + indent + indent + cloudlet.getVmId()
						+ indent + indent
						+ dft.format(cloudlet.getActualCPUTime()) + indent
						+ indent + dft.format(cloudlet.getExecStartTime())
						+ indent + indent
						+ dft.format(cloudlet.getFinishTime()));
			}
		}
	}
	
    
}
