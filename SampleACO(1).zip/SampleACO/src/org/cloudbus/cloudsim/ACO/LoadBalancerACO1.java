/*
 * This is a bio inspired algorithms, By: Thanaa Salem.

 */

package org.cloudbus.cloudsim.ACO;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import static org.apache.commons.math3.stat.StatUtils.sum;
import org.cloudbus.cloudsim.Cloudlet;
import org.cloudbus.cloudsim.Vm;

/**
 *
 * @author Thanaa
 */
public class LoadBalancerACO1 {


//number of VMs
    int m;
//number of cloudlets
    int n;
//number of iterations
    int numberOfIterations = 10;
    
    Random ran = null;

//Ant Colony Optimization parameters
//number of ants
    int numberOfAnts = 10;
//array of ants
    Ant[] ants ;
        
// Holds the values of pheromones
    double OneUnitPheromone = 0.01;
//Constant that defines how quickly the pheromone trail evaporates
    double decayFactor = 0.9;
//XXXConstant that defines the attractiveness of better state transitions (from one node to another)
    double beta = 2; //HeuristicImportance:importance of computing capacity
//XXXConstant that defines the attractiveness of the pheromone trail.
    double alpha = 3; //PheromoneImportance
    double gamma = 8 ;
    private FoodSource[] randomFoodSources;
    private int[] CurrFoodSources;

    
    
    

    List<Cloudlet> run1(List<? extends Cloudlet> cloudletList, List<? extends Vm> vmList) 
    {
         ran = new Random();
        m = vmList.size();
        n = cloudletList.size();
         
        List<FoodSource> newFS = new ArrayList<FoodSource>();
        
        //initialize food
        for(int i=0;i<m; i++)
        { Vm vm=vmList.get(i);
            double capacity = vm.getNumberOfPes()*vm.getMips()+vm.getBw();
            double pheromone = capacity; 
            double lb=1; 
            double pro=0; 
                            
            FoodSource f=new FoodSource(pheromone, capacity, lb, pro);
            f.id=vm.getId();
            f.v=vm;
            newFS.add(f);
         
        }
        
        
        for(int cl=0;cl<cloudletList.size();cl++)
        {
            Cloudlet c= cloudletList.get(cl);
            System.out.println("cloudlet");
            

            //iteration
            Ant selected=null;
            for(int iter = 0; iter<numberOfIterations; iter++)
            { System.out.println("iteration"+iter);
                List <Ant> ants=new ArrayList<>();
              //initalize ant
                for(int ant=0;ant<numberOfAnts;ant++)
                {Ant a =new Ant();
                   a.initalize_ant(c, newFS);
                   ants.add(a);
                }

             //select the global best   
                if(selected==null)   
                {selected=ants.get(0);}

                for(int i=1;i<ants.size();i++)
                {
                  if(selected.v.pro> ants.get(i).v.pro)
                  {selected=ants.get(i);
                  }
                } 
             //update pheromanon
                double ToBeDeposed = 0;
                double Toevaporate= 0;
                for(int i=0;i<newFS.size();i++)
                {
                    if(selected.v==newFS.get(i))
                    {ToBeDeposed=selected.v.currPhs;
                    }
                    Toevaporate=selected.v.currPhs-OneUnitPheromone;

                    selected.v.currPhs=Toevaporate+Deposition(ToBeDeposed);   
                }
            
            
            }
            
             System.out.println("Selected food for Cloudlet"+c.getCloudletId()+"is VM id:"+selected.v.id);
             double exec=(c.getCloudletLength()/selected.v.v.getMips());
             selected.v.v.start=selected.v.v.start+exec;
             
             selected.v.ResOfVms.add(exec);
             c.setVmId(selected.v.id);
        }    

        
       
		
		return (List<Cloudlet>) cloudletList;//		
	}
        
        
        
        
        
         
    private double Deposition(double AntTrailOnFoodSourcePath) {
        
             AntTrailOnFoodSourcePath = (1-OneUnitPheromone)*AntTrailOnFoodSourcePath ;
            
             return AntTrailOnFoodSourcePath;
        
    }
    


    
}
