/*
* Tour.java
* Stores a candidate tour
*/

package org.cloudbus.cloudsim;

import java.rmi.dgc.VMID;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import static org.cloudbus.cloudsim.TourManager.vmsCreatedList;
import org.cloudbus.cloudsim.lists.VmList;

public class Tour{

    // Holds our tour of cities
    public ArrayList<Cloudlet> tour = new ArrayList<Cloudlet>();
    // Cache
    private double fitness = 0;
    private int distance = 0;
    public int fault = 0;
    
    // Constructs a blank tour
    public Tour(){
        for (int i = 0; i < TourManager.numberOfCities(); i++) {
            tour.add(null);
        }
    }
    
    public Tour(ArrayList tour){
        this.tour = tour;
    }

    // Creates a random individual
    public void generateIndividual() 
    {   
        Random rand = new Random();
         TourManager.getCity(0).vmId =TourManager.datacenter.get(0).id ;
          
          setCity(0, TourManager.getCity(0));
       // Loop through all our destination cities and add them to our tour
        for (int cityIndex = 1; cityIndex < TourManager.numberOfCities(); cityIndex++) 
        {
            int randomNum = (int) (Math.random() * TourManager.datacenter.size());
          
          System.out.print(randomNum);
          TourManager.getCity(cityIndex).vmId =TourManager.datacenter.get(randomNum).id;
          
          setCity(cityIndex, TourManager.getCity(cityIndex));
        }
        //Randomly reorder the tour
        //Collections.shuffle(tour);
        System.out.println("\n"+getDistance());
    }

    // Gets a city from the tour
    public Cloudlet getCity(int tourPosition) {
        return (Cloudlet)tour.get(tourPosition);
    }

    // Sets a city in a certain position within a tour
    public void setCity(int tourPosition, Cloudlet city) {
        tour.set(tourPosition, city);
        // If the tours been altered we need to reset the fitness and distance
        fitness = 0;
        distance = 0;
    }
    
    // Gets the tours fitness
    public double getFitness() {
        if (fitness == 0) {
            fitness =(double)getDistance() ;
        }
        return fitness;
    }
    
    // Gets the total distance of the tour
    public int getDistance(){
        if (distance == 0) {
            List<Integer> tourDistance = new ArrayList<Integer>();
           for(int k=0;k<TourManager.vmsCreatedList.size();k++)
           {
           tourDistance.add(0);
           
           }
            int tourDistance1 = 0;
            // Loop through our tour's cities
            for (int cityIndex=0; cityIndex < tourSize(); cityIndex++) 
            {
                // Get city we're travelling from
                Cloudlet fromCity = getCity(cityIndex);
//                // City we're travelling to
//                Cloudlet destinationCity;
//                
//                // Check we're not on our tour's last city, if we are set our 
//                // tour's final destination city to our starting city
//                if(cityIndex+1 < tourSize()){
//                    destinationCity = getCity(cityIndex+1);
//                }
//                else{
//                    destinationCity = getCity(0);
//                }
//                
                // Get the distance between the two cities
                
                int dis=(int) (tourDistance.get(fromCity.vmId)+ TourManager.distanceTo(fromCity));
                tourDistance.set(fromCity.vmId,dis);
                fault=(int) VmList.getById(vmsCreatedList, fromCity.getVmId()).fault;
                }
            
            
            for(int k=0;k<tourDistance.size();k++)
            {
                if(tourDistance.get(k)>distance)
                {
                 distance=tourDistance.get(k);
                }
                
            }
            
            
        }
        return distance;
    }
    
    public int getfault(){
        
            List<Integer> tourDistance = new ArrayList<Integer>();
           for(int k=0;k<TourManager.vmsCreatedList.size();k++)
           {
           tourDistance.add(0);
           
           }
            int tourDistance1 = 0;
            // Loop through our tour's cities
            for (int cityIndex=0; cityIndex < tourSize(); cityIndex++) 
            {
                // Get city we're travelling from
                Cloudlet fromCity = getCity(cityIndex);

                fault=(int) VmList.getById(vmsCreatedList, fromCity.getVmId()).fault+fault;
                }
        
        return fault;
    }

    // Get number of cities on our tour
    public int tourSize() {
        return tour.size();
    }
    
    // Check if the tour contains a city
    public boolean containsCity(Cloudlet city){
        return tour.contains(city);
    }
    
    @Override
    public String toString() {
        String geneString = "|";
        for (int i = 0; i < tourSize(); i++) {
            geneString += getCity(i)+"|";
        }
        return geneString;
    }
    
    
    
   public static void sortcloudlet()
    { 
       Cloudlet c;
        int id=0;
        for (int i=0;i<TourManager.destinationCities.size();i++) 
        {   
            c=(Cloudlet) TourManager.destinationCities.get(i);
            id=i;
            for(int j=i;j<TourManager.destinationCities.size();j++)
            {  Cloudlet c1=(Cloudlet)TourManager.destinationCities.get(j);            
              if(c.cloudletLength< c1.cloudletLength   )
              { 
               id=j;
               
              }
            }

            Collections.swap(TourManager.destinationCities,i,id);
            //Log.printLine(vmList.get(i).priority);

        }
        
        for (int i=0;i<TourManager.destinationCities.size();i++) 
        {   c=(Cloudlet) TourManager.destinationCities.get(i);
          
          System.out.println("datacenter"+c.cloudletLength);
        }
        
    
    
    }

   public static void sort()
    { 
       Vm c;
        int id=0;
        for (int i=0;i<TourManager.datacenter.size();i++) 
        {   
            c=(Vm) TourManager.datacenter.get(i);
            id=i;
            for(int j=i;j<TourManager.datacenter.size();j++)
            {  Vm c1=(Vm)TourManager.datacenter.get(j);            
              if(c.mips< c1.mips  )
              { 
               id=j;
               
              }
            }

            Collections.swap(TourManager.datacenter,i,id);
            //Log.printLine(vmList.get(i).priority);

        }
        
        for (int i=0;i<TourManager.datacenter.size();i++) 
        {   c= TourManager.datacenter.get(i);
          
          System.out.println("datacenter"+c.mips);
        }
        
    
    
    }

   
   
}
