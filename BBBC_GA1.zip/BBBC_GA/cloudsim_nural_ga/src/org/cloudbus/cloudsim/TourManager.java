/*
* TourManager.java
* Holds the cities of a tour
*/

package org.cloudbus.cloudsim;

import java.util.ArrayList;
import java.util.List;
import org.cloudbus.cloudsim.lists.VmList;

public class TourManager {

    // Holds our cities
    public static ArrayList<Cloudlet> destinationCities = new ArrayList<Cloudlet>();
    public static ArrayList<Vm> datacenter = new ArrayList<Vm>();
    public static List< Vm> vmsCreatedList=new ArrayList<Vm>();
    // Adds a destination city
    public static void addCity(Cloudlet city) {
        destinationCities.add(city);
    }
    
    // Get a city
    public static Cloudlet getCity(int index){
        return (Cloudlet)destinationCities.get(index);
    }
    
    // Get the number of destination cities
    public static int numberOfCities(){
        return destinationCities.size();
    }
    
    
    public static double distanceTo(Cloudlet city)
    {  
    
        Vm v  = VmList.getById(vmsCreatedList, city.getVmId());
        double distance=city.cloudletLength/v.getMips();
        //System.out.println(distance);
        return distance;
    }
}
