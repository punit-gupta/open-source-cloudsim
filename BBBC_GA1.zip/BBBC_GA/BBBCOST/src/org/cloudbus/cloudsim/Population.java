/*
* Population.java
* Manages a population of candidate tours
*/

package org.cloudbus.cloudsim;

public class Population {

    // Holds population of tours
    Tour[] tours;

    // Construct a population
    public Population(int populationSize, boolean initialise) {
        tours = new Tour[populationSize];
        // If we need to initialise a population of tours do so
        if (initialise) {
            // Loop and create individuals
            for (int i = 0; i < populationSize(); i++) {
                Tour newTour = new Tour();
                newTour.generateIndividual(1);
                saveTour(i, newTour);
            }
        }
    }
    
    // Saves a tour
    public void saveTour(int index, Tour tour) {
        tours[index] = tour;
    }
    
    // Gets a tour from population
    
    public Tour getTour(int index) {
        return tours[index];
    }
 public Tour getFittest1() {
        Tour fittest = tours[0];
        // Loop through individuals to find fittest
        for (int i = 1; i < populationSize(); i++)
        {
            if (fittest.getFitness() >= getTour(i).getFitness()) {
                fittest = getTour(i);
            }
        }
        
        return fittest;
    }
 
 
 
 public Population remove()
 {int ind=0;
 int size=populationSize();
 Tour[] tou=new Tour[size-1];
 Tour t=getFittest1();
System.out.println(populationSize());
 
 
         for (int i = 0; i < populationSize(); i++)
        {
            if (t.getFitness()== getTour(i).getFitness())
            {
             ind=i;   
            }
        }
      
      for (int i = 0; i < ind; i++)
        {   
           tou[i]=tours[i];
             
        }
        for (int i = ind; i < populationSize()-1; i++)
        {   
           tou[i]=tours[i+1];
             
        }
 tours=tou;
 System.out.println(populationSize());
 return this;
 }
 
    // Gets the best tour in the population
    public Tour getFittest() {
        double fitness_mean=0;
        double mass_diff=0;
        double mass_diff_t=0;
        Tour fittest = tours[0];
        // Loop through individuals to find fittest
        for (int i = 0; i < populationSize(); i++)
        {
            fitness_mean= fitness_mean+ tours[i].getFitness();
           
        }
        
        fitness_mean=fitness_mean/populationSize();
        System.out.println("fitness mean---"+ fitness_mean);
        mass_diff=fitness_mean-tours[0].getFitness();
        
        for (int i = 0; i < populationSize(); i++)
        { mass_diff_t=fitness_mean-tours[i].getFitness();
        
            if (mass_diff >= mass_diff_t) {
                fittest = getTour(i);
                mass_diff=mass_diff_t;
            }
        }
        System.out.println("fitest cost :"+ fittest.cost);
        return fittest;
    }

    // Gets population size
    public int populationSize() {
        return tours.length;
    }
}
